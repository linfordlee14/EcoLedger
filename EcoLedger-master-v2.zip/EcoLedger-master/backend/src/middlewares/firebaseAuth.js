const { verifyIdToken, initFirebaseAdmin } = require('../services/firebaseAdmin');

const firebaseAuth = ({ optional = false } = {}) => {
  return async (req, res, next) => {
    try {
      initFirebaseAdmin();
      const authHeader = req.headers.authorization || req.headers.Authorization;
      if (!authHeader) {
        if (optional) {
          return next();
        }
        return res.status(401).json({ message: 'Missing Authorization header' });
      }

      const [scheme, token] = authHeader.split(' ');
      if (scheme !== 'Bearer' || !token) {
        if (optional) {
          return next();
        }
        return res.status(401).json({ message: 'Invalid Authorization header' });
      }

      const decoded = await verifyIdToken(token);
      req.firebaseUser = decoded;
      return next();
    } catch (error) {
      if (optional) {
        return next();
      }
      return res.status(401).json({ message: 'Firebase authentication failed', error: error.message });
    }
  };
};

module.exports = firebaseAuth;
module.exports.optional = firebaseAuth({ optional: true });
