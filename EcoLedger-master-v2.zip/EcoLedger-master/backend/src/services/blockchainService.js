const fs = require('fs');
const path = require('path');
const { ethers } = require('ethers');

let provider;
let wallet;
let contract;
let cachedAbi;

const loadAbi = () => {
  if (cachedAbi) return cachedAbi;
  const abiPath = process.env.ECO_LEDGER_ABI_PATH
    ? (path.isAbsolute(process.env.ECO_LEDGER_ABI_PATH)
        ? process.env.ECO_LEDGER_ABI_PATH
        : path.join(process.cwd(), process.env.ECO_LEDGER_ABI_PATH))
    : path.join(__dirname, '../blockchain/abi/EcoLedger.json');

  try {
    const raw = fs.readFileSync(abiPath, 'utf8');
    const parsed = JSON.parse(raw);
    cachedAbi = parsed.abi || parsed;
    return cachedAbi;
  } catch (error) {
    console.warn('[blockchain] ABI not found at', abiPath, '- on-chain logging will be skipped.');
    cachedAbi = null;
    return cachedAbi;
  }
};

const ensureProvider = () => {
  if (provider) return provider;
  const rpcUrl = process.env.BLOCKCHAIN_RPC_URL || process.env.POLYGON_RPC_URL;
  if (!rpcUrl) {
    console.warn('[blockchain] BLOCKCHAIN_RPC_URL not set.');
    return null;
  }
  provider = new ethers.JsonRpcProvider(rpcUrl);
  return provider;
};

const ensureWallet = () => {
  if (wallet) return wallet;
  const rpcProvider = ensureProvider();
  const privateKey = process.env.BLOCKCHAIN_PRIVATE_KEY || process.env.PRIVATE_KEY;
  if (!rpcProvider || !privateKey) {
    console.warn('[blockchain] Missing provider or private key.');
    return null;
  }
  wallet = new ethers.Wallet(privateKey, rpcProvider);
  return wallet;
};

const ensureContract = () => {
  if (contract) return contract;
  const abi = loadAbi();
  const address = process.env.ECO_LEDGER_CONTRACT_ADDRESS;
  const signer = ensureWallet();
  if (!abi || !address || !signer) {
    return null;
  }
  contract = new ethers.Contract(address, abi, signer);
  return contract;
};

const isConfigured = () => Boolean(loadAbi() && ensureContract());

const logEmissionOnChain = async ({ amountKg, activityType, isReduction = false }) => {
  try {
    const ecoLedger = ensureContract();
    if (!ecoLedger) {
      return { skipped: true, reason: 'Blockchain not configured' };
    }

    const tx = await ecoLedger.logEmission(
      Math.round(Number(amountKg) || 0),
      activityType,
      Boolean(isReduction)
    );

    const receipt = await tx.wait();
    return {
      skipped: false,
      transactionHash: receipt?.hash || tx?.hash,
      blockNumber: receipt?.blockNumber,
    };
  } catch (error) {
    console.error('[blockchain] logEmission failed:', error.message);
    return { skipped: true, reason: error.message };
  }
};

module.exports = {
  isConfigured,
  logEmissionOnChain,
};
