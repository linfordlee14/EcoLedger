const admin = require('firebase-admin');
const { getFirestore } = require('./firebaseAdmin');

const DAILY_BONUS = 10;
const LOW_EMISSION_THRESHOLD = 50;
const DEFAULT_BASELINE = {
  monthly: 1000,
  transport: 400,
  energy: 400,
  food: 200,
};

const getDbOrThrow = () => {
  const db = getFirestore();
  if (!db) {
    throw new Error('Firestore is not configured. Provide Firebase service account credentials to enable persistence.');
  }
  return db;
};

const normaliseBaseline = (baseline = {}) => ({
  monthly: Number(baseline.monthly) || DEFAULT_BASELINE.monthly,
  transport: Number(baseline.transport) || DEFAULT_BASELINE.transport,
  energy: Number(baseline.energy) || DEFAULT_BASELINE.energy,
  food: Number(baseline.food) || DEFAULT_BASELINE.food,
});

const calculatePoints = (amountKg, isReduction) => {
  let points = 0;
  if (amountKg < LOW_EMISSION_THRESHOLD) {
    points = (LOW_EMISSION_THRESHOLD - amountKg) * 2;
  }
  if (isReduction) {
    points *= 2;
  }
  return Math.max(5, Math.round(points));
};

const buildUserDefaults = (userId, overrides = {}) => ({
  userId,
  totalEmissions: 0,
  totalPoints: 0,
  streak: 0,
  lastLogAt: null,
  baseline: normaliseBaseline(overrides.baseline),
  walletAddress: overrides.walletAddress || null,
  createdAt: overrides.createdAt || admin.firestore.Timestamp.now(),
});

const upsertUserProfile = async (userId, payload = {}) => {
  if (!userId) throw new Error('userId is required to update a profile');
  const db = getDbOrThrow();
  const userRef = db.collection('users').doc(userId);
  const update = { ...payload };

  if (payload.baseline) {
    update.baseline = normaliseBaseline(payload.baseline);
  }
  if (payload.walletAddress) {
    update.walletAddress = payload.walletAddress;
  }
  update.updatedAt = admin.firestore.FieldValue.serverTimestamp();

  await userRef.set(update, { merge: true });
  const saved = await userRef.get();
  return saved.data();
};

const getUserProfile = async (userId) => {
  if (!userId) throw new Error('userId is required to load profile');
  const db = getDbOrThrow();
  const userRef = db.collection('users').doc(userId);
  const snap = await userRef.get();

  if (!snap.exists) {
    const defaults = buildUserDefaults(userId);
    await userRef.set(defaults, { merge: true });
    return defaults;
  }

  const data = snap.data();
  return { ...buildUserDefaults(userId), ...data };
};

const logEmissionRecord = async ({
  userId,
  amountKg,
  activityType,
  isReduction = false,
  details = {},
  aiSummary = {},
  txHash = null,
}) => {
  if (!userId) throw new Error('userId is required');
  if (!activityType) throw new Error('activityType is required');

  const db = getDbOrThrow();
  const userRef = db.collection('users').doc(userId);
  const emissionRef = db.collection('emissions').doc();
  const leaderboardRef = db.collection('leaderboard').doc(userId);
  const now = admin.firestore.Timestamp.now();

  let response = null;

  await db.runTransaction(async (transaction) => {
    const userSnap = await transaction.get(userRef);
    const userData = userSnap.exists ? userSnap.data() : buildUserDefaults(userId);

    const lastLogAt = userData.lastLogAt ? userData.lastLogAt.toDate() : null;
    const timeDiff = lastLogAt ? now.toDate() - lastLogAt : null;
    const withinDay = timeDiff !== null && timeDiff <= 24 * 60 * 60 * 1000;
    const streak = withinDay ? (userData.streak || 0) + 1 : 1;

    const pointsAwarded = calculatePoints(Number(amountKg) || 0, isReduction) + (withinDay ? DAILY_BONUS : 0);
    const totalPoints = (userData.totalPoints || 0) + pointsAwarded;
    const totalEmissions = (userData.totalEmissions || 0) + (Number(amountKg) || 0);

    const breakdown = {
      transport: userData.breakdown?.transport || 0,
      energy: userData.breakdown?.energy || 0,
      food: userData.breakdown?.food || 0,
      waste: userData.breakdown?.waste || 0,
    };
    breakdown[activityType] = (breakdown[activityType] || 0) + (Number(amountKg) || 0);

    const emissionPayload = {
      userId,
      amountKg: Number(amountKg) || 0,
      activityType,
      timestamp: now,
      isReduction,
      details,
      aiSummary,
      txHash: txHash || null,
      pointsAwarded,
    };

    transaction.set(emissionRef, emissionPayload);

    transaction.set(userRef, {
      ...buildUserDefaults(userId, userData),
      totalPoints,
      totalEmissions,
      streak,
      lastLogAt: now,
      breakdown,
      updatedAt: now,
    }, { merge: true });

    transaction.set(leaderboardRef, {
      userId,
      totalPoints,
      totalEmissions,
      lastActivityAt: now,
      displayName: userData.displayName || null,
      walletAddress: userData.walletAddress || null,
    }, { merge: true });

    response = {
      emission: emissionPayload,
      user: {
        userId,
        totalPoints,
        totalEmissions,
        streak,
        breakdown,
      },
    };
  });

  return response;
};

const getEmissionsForUser = async (userId, { limit = 25 } = {}) => {
  if (!userId) throw new Error('userId is required');
  const db = getDbOrThrow();
  const snapshot = await db
    .collection('emissions')
    .where('userId', '==', userId)
    .orderBy('timestamp', 'desc')
    .limit(limit)
    .get();

  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
};

const getLeaderboard = async ({ limit = 10 } = {}) => {
  const db = getDbOrThrow();
  const snapshot = await db
    .collection('leaderboard')
    .orderBy('totalPoints', 'desc')
    .limit(limit)
    .get();

  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
};

module.exports = {
  upsertUserProfile,
  getUserProfile,
  logEmissionRecord,
  getEmissionsForUser,
  getLeaderboard,
};
