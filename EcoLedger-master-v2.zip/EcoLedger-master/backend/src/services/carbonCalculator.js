const EMISSION_FACTORS = {
  transport: {
    car_gasoline: 0.21,
    car_diesel: 0.17,
    car_electric: 0.05,
    bus: 0.089,
    train: 0.041,
    bicycle: 0,
    walking: 0,
    flight_domestic: 0.255,
    flight_international: 0.195,
  },
  energy: {
    electricity_grid: 0.4,
    electricity_renewable: 0.02,
    natural_gas: 0.185,
    heating_oil: 0.28,
    solar: 0,
    wind: 0,
  },
  food: {
    beef: 27.0,
    chicken: 6.9,
    pork: 12.1,
    fish: 5.0,
    dairy: 1.9,
    eggs: 4.8,
    vegetables: 2.0,
    fruits: 1.1,
    grains: 1.0,
    vegan_meal: 1.5,
    vegetarian_meal: 2.5,
    meat_meal: 6.5,
  },
  waste: {
    landfill: 467,
    recycling: -20,
    composting: -10,
  },
};

const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

const withVariance = (value, variance = 0.2) => {
  const delta = (Math.random() - 0.5) * variance;
  return value * (1 + delta);
};

const generateInsights = (type, emission, details) => {
  const insights = [];

  if (emission > 20) {
    insights.push('High emission activity detected. Consider lower-impact alternatives.');
  } else if (emission < 5) {
    insights.push('Low carbon footprint — great job keeping emissions down.');
  }

  switch (type) {
    case 'transport':
      if (details.distance > 50) {
        insights.push('Long trips dominate this entry. Carpooling or public transport could cut emissions by 60-70%.');
      }
      if (details.mode === 'car_gasoline') {
        insights.push('Switching to an electric or hybrid vehicle could save roughly 75% of the emissions.');
      }
      break;
    case 'energy':
      if (details.usage > 30) {
        insights.push('Above-average energy usage; checking insulation and appliance efficiency may help.');
      }
      insights.push('Align heavy appliance use with off-peak hours to reduce grid emissions intensity.');
      break;
    case 'food':
      if (details.type && details.type.includes('meat')) {
        insights.push('Animal proteins carry high emissions — swapping a few meals for plant-based dishes helps significantly.');
      }
      break;
    default:
      break;
  }

  return insights;
};

const generateBreakdown = (type) => {
  switch (type) {
    case 'transport':
      return { fuel: 70, manufacturing: 20, maintenance: 10 };
    case 'energy':
      return { generation: 60, transmission: 25, infrastructure: 15 };
    case 'food':
      return { production: 50, transport: 30, packaging: 15, waste: 5 };
    case 'waste':
      return { methane: 60, transport: 25, handling: 15 };
    default:
      return {};
  }
};

const generateAlternatives = (type, currentEmission) => {
  const alternatives = [];

  switch (type) {
    case 'transport':
      alternatives.push({ option: 'Public transport', emission: (currentEmission * 0.3).toFixed(2), savings: '~70%' });
      alternatives.push({ option: 'Cycling or walking', emission: 0, savings: '~100%' });
      alternatives.push({ option: 'Electric vehicle', emission: (currentEmission * 0.24).toFixed(2), savings: '~76%' });
      break;
    case 'energy':
      alternatives.push({ option: 'Solar or wind supply', emission: (currentEmission * 0.05).toFixed(2), savings: '~95%' });
      alternatives.push({ option: 'Heat pump upgrade', emission: (currentEmission * 0.6).toFixed(2), savings: '~40%' });
      break;
    case 'food':
      alternatives.push({ option: 'Plant-based meal', emission: (currentEmission * 0.2).toFixed(2), savings: '~80%' });
      alternatives.push({ option: 'Local & seasonal sourcing', emission: (currentEmission * 0.8).toFixed(2), savings: '~20%' });
      break;
    case 'waste':
      alternatives.push({ option: 'Composting', emission: (currentEmission * 0.15).toFixed(2), savings: '~85%' });
      alternatives.push({ option: 'Recycling program', emission: (currentEmission * 0.3).toFixed(2), savings: '~70%' });
      break;
    default:
      break;
  }

  return alternatives;
};

const baseEmissionForActivity = (activityType, details = {}) => {
  switch (activityType) {
    case 'transport': {
      const mode = details.mode || 'car_gasoline';
      const factor = EMISSION_FACTORS.transport[mode] ?? EMISSION_FACTORS.transport.car_gasoline;
      const distance = Number(details.distance) || 0;
      let emission = factor * distance;

      if (details.traffic === 'heavy') emission *= 1.2;
      if (details.vehicleAge && Number(details.vehicleAge) > 10) emission *= 1.1;
      if (details.passengers && Number(details.passengers) > 1) {
        emission /= Number(details.passengers);
      }
      return emission;
    }
    case 'energy': {
      const type = details.type || 'electricity_grid';
      const factor = EMISSION_FACTORS.energy[type] ?? EMISSION_FACTORS.energy.electricity_grid;
      const usage = Number(details.usage) || 0;
      let emission = factor * usage;

      const month = new Date().getMonth();
      if (month >= 11 || month <= 1) emission *= 1.25; // winter heating bump
      if (month >= 5 && month <= 8) emission *= 0.92; // summer renewable mix
      if (details.renewableShare) {
        emission *= clamp(1 - Number(details.renewableShare) / 100, 0, 1);
      }
      return emission;
    }
    case 'food': {
      const type = details.type || 'vegetarian_meal';
      const factor = EMISSION_FACTORS.food[type] ?? EMISSION_FACTORS.food.vegetarian_meal;
      const quantity = Number(details.quantity || details.meals || 1);
      let emission = factor * quantity;

      if (details.isLocal) emission *= 0.82;
      if (details.isOrganic) emission *= 0.9;
      return emission;
    }
    case 'waste': {
      const type = details.type || 'landfill';
      const factor = EMISSION_FACTORS.waste[type] ?? EMISSION_FACTORS.waste.landfill;
      const weight = Number(details.weight) || 0;
      return (factor * weight) / 1000;
    }
    default:
      return 10;
  }
};

const calculateCarbonEmission = (activityType, details = {}) => {
  const baseEmission = baseEmissionForActivity(activityType, details);
  const emission = Math.max(0, withVariance(baseEmission, 0.1));
  const confidence = clamp(0.8 + Math.random() * 0.15, 0, 0.99);

  return {
    activityType,
    emission: Number(emission.toFixed(2)),
    confidence: Number(confidence.toFixed(2)),
    unit: 'kg CO2e',
    insights: generateInsights(activityType, emission, details),
    breakdown: generateBreakdown(activityType),
    alternatives: generateAlternatives(activityType, emission),
  };
};

const batchCalculate = (activities = []) => activities.map((activity) =>
  calculateCarbonEmission(activity.type, activity.details)
);

const getUserRecommendations = (emissionHistory = []) => {
  if (!Array.isArray(emissionHistory) || !emissionHistory.length) {
    return [];
  }

  const totals = emissionHistory.reduce((acc, entry) => {
    const amount = Number(entry.amount || entry.emission || 0);
    acc.total += amount;
    acc.count += 1;
    acc.byType[entry.type] = (acc.byType[entry.type] || 0) + amount;
    return acc;
  }, { total: 0, count: 0, byType: {} });

  const recommendations = [];
  const avgEmission = totals.total / totals.count;

  if (avgEmission > 50) {
    recommendations.push({
      priority: 'high',
      category: 'general',
      suggestion: 'Average emission per activity is high. Focus on the most carbon intensive categories first.',
      action: 'Set a weekly reduction target and prioritise low-emission alternatives for frequent activities.',
      potentialSaving: '~25% if maintained for 30 days',
    });
  }

  const transportShare = totals.byType.transport || 0;
  if (transportShare > totals.total * 0.5) {
    recommendations.push({
      priority: 'high',
      category: 'transport',
      suggestion: 'Transportation dominates your footprint (over 50%).',
      action: 'Swap two weekly solo car trips for public transport or biking.',
      potentialSaving: '~35% transport emissions',
    });
  }

  const energyShare = totals.byType.energy || 0;
  if (energyShare > 0 && !emissionHistory.some((entry) => entry.details?.type === 'electricity_renewable')) {
    recommendations.push({
      priority: 'medium',
      category: 'energy',
      suggestion: 'Renewable energy usage not detected.',
      action: 'Enroll in a green tariff or add rooftop solar to cut energy emissions.',
      potentialSaving: '~60-80%',
    });
  }

  const foodShare = totals.byType.food || 0;
  if (foodShare < totals.total * 0.2) {
    recommendations.push({
      priority: 'low',
      category: 'food',
      suggestion: 'Food emissions already efficient — keep up the sustainable choices.',
      action: 'Share your meal plans with the community challenge for bonus GreenPoints.',
      potentialSaving: 'Already optimised',
    });
  }

  return recommendations;
};

module.exports = {
  calculateCarbonEmission,
  batchCalculate,
  getUserRecommendations,
};

