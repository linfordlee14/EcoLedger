const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');

let hasAttemptedInit = false;

const resolveServiceAccount = () => {
  if (process.env.FIREBASE_SERVICE_ACCOUNT_BASE64) {
    try {
      const json = Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64, 'base64').toString('utf8');
      return JSON.parse(json);
    } catch (error) {
      console.error('[firebaseAdmin] Failed to parse FIREBASE_SERVICE_ACCOUNT_BASE64:', error.message);
      return null;
    }
  }

  if (process.env.FIREBASE_SERVICE_ACCOUNT_PATH) {
    try {
      const absolutePath = path.isAbsolute(process.env.FIREBASE_SERVICE_ACCOUNT_PATH)
        ? process.env.FIREBASE_SERVICE_ACCOUNT_PATH
        : path.join(process.cwd(), process.env.FIREBASE_SERVICE_ACCOUNT_PATH);
      const raw = fs.readFileSync(absolutePath, 'utf8');
      return JSON.parse(raw);
    } catch (error) {
      console.error('[firebaseAdmin] Failed to read FIREBASE_SERVICE_ACCOUNT_PATH:', error.message);
      return null;
    }
  }

  const projectId = process.env.FIREBASE_PROJECT_ID;
  const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY;
  if (projectId && clientEmail && privateKey) {
    return {
      project_id: projectId,
      client_email: clientEmail,
      private_key: privateKey.replace(/\\n/g, '\n'),
    };
  }

  return null;
};

const initFirebaseAdmin = () => {
  if (hasAttemptedInit) {
    return admin.apps.length ? admin.app() : null;
  }

  hasAttemptedInit = true;

  if (admin.apps.length) {
    return admin.app();
  }

  const serviceAccount = resolveServiceAccount();
  if (!serviceAccount) {
    console.warn('[firebaseAdmin] No service account configuration detected. Firestore & token verification will be disabled.');
    return null;
  }

  try {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      projectId: serviceAccount.project_id,
    });
    return admin.app();
  } catch (error) {
    console.error('[firebaseAdmin] Firebase admin initialization failed:', error.message);
    return null;
  }
};

const getFirestore = () => {
  const app = initFirebaseAdmin();
  return app ? admin.firestore() : null;
};

const getAuth = () => {
  const app = initFirebaseAdmin();
  return app ? admin.auth() : null;
};

const verifyIdToken = async (token) => {
  const auth = getAuth();
  if (!auth) {
    throw new Error('Firebase admin not configured. Provide service account credentials to enable auth.');
  }
  return auth.verifyIdToken(token);
};

module.exports = {
  initFirebaseAdmin,
  getFirestore,
  getAuth,
  verifyIdToken,
};
