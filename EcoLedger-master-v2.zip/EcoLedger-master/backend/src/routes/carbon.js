const express = require('express');
const firebaseAuth = require('../middlewares/firebaseAuth');
const carbonCalculator = require('../services/carbonCalculator');
const firestoreService = require('../services/firestoreService');
const blockchainService = require('../services/blockchainService');
const { initFirebaseAdmin, getFirestore } = require('../services/firebaseAdmin');

const router = express.Router();

router.post('/calculate', firebaseAuth.optional, async (req, res) => {
  try {
    const { activityType, details = {} } = req.body || {};
    if (!activityType) {
      return res.status(400).json({ message: 'activityType is required' });
    }

    const estimation = carbonCalculator.calculateCarbonEmission(activityType, details);
    return res.json({ estimation });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to calculate emissions', error: error.message });
  }
});

router.post('/profile', firebaseAuth(), async (req, res) => {
  try {
    const user = req.firebaseUser;
    const { baseline, walletAddress, displayName } = req.body || {};

    const profile = await firestoreService.upsertUserProfile(user.uid, {
      baseline,
      walletAddress,
      displayName: displayName || user.name || user.email,
      email: user.email,
    });

    return res.json({ profile });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to update profile', error: error.message });
  }
});

router.get('/profile', firebaseAuth(), async (req, res) => {
  try {
    const user = req.firebaseUser;
    const profile = await firestoreService.getUserProfile(user.uid);
    return res.json({ profile });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to load profile', error: error.message });
  }
});

router.post('/log', firebaseAuth(), async (req, res) => {
  try {
    const user = req.firebaseUser;
    const {
      activityType,
      details = {},
      isReduction = false,
      amountOverride,
      baseline,
    } = req.body || {};

    if (!activityType) {
      return res.status(400).json({ message: 'activityType is required' });
    }

    const estimation = carbonCalculator.calculateCarbonEmission(activityType, details);
    const amountKg = amountOverride !== undefined ? Number(amountOverride) : estimation.emission;

    if (baseline || req.body.walletAddress || req.body.displayName) {
      await firestoreService.upsertUserProfile(user.uid, {
        baseline,
        walletAddress: req.body.walletAddress,
        displayName: req.body.displayName,
      });
    }

    const chainResult = await blockchainService.logEmissionOnChain({
      amountKg,
      activityType,
      isReduction,
    });

    const record = await firestoreService.logEmissionRecord({
      userId: user.uid,
      amountKg,
      activityType,
      isReduction,
      details,
      aiSummary: estimation,
      txHash: chainResult.skipped ? null : chainResult.transactionHash,
    });

    return res.json({
      estimation,
      blockchain: chainResult,
      record,
    });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to log emission', error: error.message });
  }
});

router.get('/history', firebaseAuth(), async (req, res) => {
  try {
    const user = req.firebaseUser;
    const limit = req.query.limit ? Number(req.query.limit) : 25;
    const emissions = await firestoreService.getEmissionsForUser(user.uid, { limit });
    return res.json({ emissions });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to load history', error: error.message });
  }
});

router.get('/leaderboard', firebaseAuth.optional, async (req, res) => {
  try {
    const limit = req.query.limit ? Number(req.query.limit) : 10;
    const leaderboard = await firestoreService.getLeaderboard({ limit });
    return res.json({ leaderboard });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to load leaderboard', error: error.message });
  }
});


router.get('/status', firebaseAuth.optional, (req, res) => {
  try {
    initFirebaseAdmin();
    const firestoreReady = Boolean(getFirestore());
    const blockchainReady = blockchainService.isConfigured();
    return res.json({ firestoreConfigured: firestoreReady, blockchainConfigured: blockchainReady });
  } catch (error) {
    const blockchainReady = blockchainService.isConfigured();
    return res.json({ firestoreConfigured: false, blockchainConfigured: blockchainReady, error: error.message });
  }
});

router.get('/insights', firebaseAuth(), async (req, res) => {
  try {
    const user = req.firebaseUser;
    const emissions = await firestoreService.getEmissionsForUser(user.uid, { limit: 100 });
    const recommendations = carbonCalculator.getUserRecommendations(emissions);
    return res.json({ recommendations });
  } catch (error) {
    return res.status(500).json({ message: 'Failed to load insights', error: error.message });
  }
});

module.exports = router;
