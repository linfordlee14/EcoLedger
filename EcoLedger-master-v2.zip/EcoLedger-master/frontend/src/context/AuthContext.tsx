import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup,
  onIdTokenChanged,
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase/client';

const TOKEN_STORAGE_KEY = 'ecoledger_idToken';

export type AuthContextValue = {
  user: User | null;
  loading: boolean;
  idToken: string | null;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (email: string, password: string) => Promise<void>;
  refreshIdToken: () => Promise<string | null>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const storeToken = (token: string | null) => {
  if (typeof window === 'undefined') return;
  if (token) {
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  }
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [idToken, setIdToken] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onIdTokenChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const token = await currentUser.getIdToken();
        setIdToken(token);
        storeToken(token);
      } else {
        setIdToken(null);
        storeToken(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signInWithGoogleHandler = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const signInWithEmail = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const registerWithEmail = async (email: string, password: string) => {
    await createUserWithEmailAndPassword(auth, email, password);
  };

  const refreshIdToken = async () => {
    if (!auth.currentUser) {
      storeToken(null);
      setIdToken(null);
      return null;
    }
    const token = await auth.currentUser.getIdToken(true);
    setIdToken(token);
    storeToken(token);
    return token;
  };

  const logout = async () => {
    await signOut(auth);
    storeToken(null);
    setIdToken(null);
  };

  const value = useMemo<AuthContextValue>(() => ({
    user,
    loading,
    idToken,
    signInWithGoogle: signInWithGoogleHandler,
    signInWithEmail,
    registerWithEmail,
    refreshIdToken,
    logout,
  }), [user, loading, idToken]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
