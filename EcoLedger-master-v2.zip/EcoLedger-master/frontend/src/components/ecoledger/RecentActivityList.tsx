import React from 'react';

type EmissionRecord = {
  id: string;
  activityType: string;
  amountKg: number;
  timestamp: { seconds: number } | string | Date;
  txHash?: string | null;
  aiSummary?: { insights?: string[] };
};

type RecentActivityListProps = {
  records: EmissionRecord[];
};

const toDisplayDate = (value: EmissionRecord['timestamp']) => {
  if (!value) return '';
  if (value instanceof Date) return value.toLocaleString();
  if (typeof value === 'string') return new Date(value).toLocaleString();
  if ('seconds' in value) return new Date(value.seconds * 1000).toLocaleString();
  return '';
};

const typeLabels: Record<string, string> = {
  transport: 'Transport',
  energy: 'Energy',
  food: 'Food',
  waste: 'Waste',
};

const RecentActivityList: React.FC<RecentActivityListProps> = ({ records }) => {
  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Recent Activity</h3>
      <ul className="space-y-3">
        {records.map((record) => (
          <li key={record.id} className="border border-slate-200 rounded-md p-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-semibold text-slate-800">
                {typeLabels[record.activityType] || 'Activity'}
              </span>
              <span className="text-sm text-green-700 font-semibold">{record.amountKg} kg</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">{toDisplayDate(record.timestamp)}</p>
            {record.aiSummary?.insights && record.aiSummary.insights.length > 0 && (
              <ul className="mt-2 text-xs text-slate-600 list-disc list-inside space-y-1">
                {record.aiSummary.insights.slice(0, 2).map((insight, idx) => (
                  <li key={idx}>{insight}</li>
                ))}
              </ul>
            )}
            {record.txHash && (
              <a
                href={`https://mumbai.polygonscan.com/tx/${record.txHash}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-blue-600 hover:underline mt-2 inline-block"
              >
                View on Polygonscan
              </a>
            )}
          </li>
        ))}
        {!records.length && <li className="text-sm text-slate-500">Log an activity to see it here.</li>}
      </ul>
    </div>
  );
};

export default RecentActivityList;
