import React, { useMemo } from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  TimeScale,
} from 'chart.js';
import 'chartjs-adapter-date-fns';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend, TimeScale);

type EmissionRecord = {
  id?: string;
  timestamp: { seconds: number } | string | Date;
  amountKg: number;
  activityType: string;
};

type EmissionsChartProps = {
  records: EmissionRecord[];
};

const toDate = (value: EmissionRecord['timestamp']) => {
  if (!value) return new Date();
  if (value instanceof Date) return value;
  if (typeof value === 'string') return new Date(value);
  if (typeof value === 'object' && 'seconds' in value) {
    return new Date(value.seconds * 1000);
  }
  return new Date();
};

const EmissionsChart: React.FC<EmissionsChartProps> = ({ records }) => {
  const chartData = useMemo(() => {
    const sorted = [...records].sort((a, b) => toDate(a.timestamp).getTime() - toDate(b.timestamp).getTime());
    return {
      labels: sorted.map((record) => toDate(record.timestamp)),
      datasets: [
        {
          label: 'Emissions (kg CO2e)',
          data: sorted.map((record) => record.amountKg),
          borderColor: '#16a34a',
          backgroundColor: 'rgba(22, 163, 74, 0.2)',
          tension: 0.25,
          fill: true,
        },
      ],
    };
  }, [records]);

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      x: {
        type: 'time' as const,
        time: { tooltipFormat: 'PP p', unit: 'day' },
        ticks: { color: '#1f2937' },
        grid: { display: false },
      },
      y: {
        ticks: { color: '#1f2937' },
        grid: { color: 'rgba(31, 41, 55, 0.1)' },
        beginAtZero: true,
      },
    },
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (context: any) => `${context.parsed.y} kg`,
        },
      },
    },
  }), []);

  return (
    <div className="w-full h-64">
      <Line data={chartData} options={options} />
    </div>
  );
};

export default EmissionsChart;
