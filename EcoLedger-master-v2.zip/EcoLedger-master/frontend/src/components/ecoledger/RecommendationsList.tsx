import React from 'react';

type Recommendation = {
  priority: 'high' | 'medium' | 'low';
  category: string;
  suggestion: string;
  action: string;
  potentialSaving?: string;
};

type RecommendationsListProps = {
  items: Recommendation[];
};

const badgeColors: Record<Recommendation['priority'], string> = {
  high: 'bg-red-100 text-red-700',
  medium: 'bg-yellow-100 text-yellow-700',
  low: 'bg-blue-100 text-blue-700',
};

const RecommendationsList: React.FC<RecommendationsListProps> = ({ items }) => {
  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">AI Recommendations</h3>
      <div className="space-y-4">
        {items.map((item, index) => (
          <div key={`${item.category}-${index}`} className="border border-slate-200 rounded-md p-3">
            <div className="flex justify-between items-start">
              <span className={`text-xs font-semibold uppercase px-2 py-1 rounded ${badgeColors[item.priority]}`}>
                {item.priority} priority
              </span>
              <span className="text-xs text-slate-500">{item.category}</span>
            </div>
            <p className="text-sm font-medium text-slate-800 mt-2">{item.suggestion}</p>
            <p className="text-sm text-slate-600 mt-1">Action: {item.action}</p>
            {item.potentialSaving && (
              <p className="text-xs text-slate-500 mt-1">Potential saving: {item.potentialSaving}</p>
            )}
          </div>
        ))}
        {!items.length && <p className="text-sm text-slate-500">Log activities to receive personalised insights.</p>}
      </div>
    </div>
  );
};

export default RecommendationsList;
