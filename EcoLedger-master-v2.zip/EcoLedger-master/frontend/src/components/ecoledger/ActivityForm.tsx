import React, { useMemo, useState } from 'react';
import type { ActivityType, ActivityDetails } from '../../lib/carbonApi';

type ActivityFormProps = {
  loading: boolean;
  onSubmit: (payload: { activityType: ActivityType; details: ActivityDetails; isReduction: boolean }) => Promise<void>;
};

const defaultDetails: Record<ActivityType, ActivityDetails> = {
  transport: { mode: 'car_gasoline', distance: 10, passengers: 1 },
  energy: { type: 'electricity_grid', usage: 15, renewableShare: 0 },
  food: { type: 'vegetarian_meal', quantity: 1, isLocal: true },
  waste: { type: 'landfill', weight: 1 },
};

const transportModes = [
  { value: 'car_gasoline', label: 'Car (Gasoline)' },
  { value: 'car_diesel', label: 'Car (Diesel)' },
  { value: 'car_electric', label: 'Car (Electric)' },
  { value: 'bus', label: 'Bus' },
  { value: 'train', label: 'Train' },
  { value: 'flight_domestic', label: 'Flight (Domestic)' },
];

const energyTypes = [
  { value: 'electricity_grid', label: 'Grid Electricity' },
  { value: 'electricity_renewable', label: '100% Renewable' },
  { value: 'natural_gas', label: 'Natural Gas' },
  { value: 'heating_oil', label: 'Heating Oil' },
];

const foodTypes = [
  { value: 'vegan_meal', label: 'Vegan Meal' },
  { value: 'vegetarian_meal', label: 'Vegetarian Meal' },
  { value: 'meat_meal', label: 'Meat-based Meal' },
  { value: 'beef', label: 'Beef (per kg)' },
  { value: 'chicken', label: 'Chicken (per kg)' },
];

const wasteTypes = [
  { value: 'landfill', label: 'Landfill' },
  { value: 'recycling', label: 'Recycling' },
  { value: 'composting', label: 'Composting' },
];

const ActivityForm: React.FC<ActivityFormProps> = ({ loading, onSubmit }) => {
  const [activityType, setActivityType] = useState<ActivityType>('transport');
  const [isReduction, setIsReduction] = useState<boolean>(false);
  const [details, setDetails] = useState<ActivityDetails>(defaultDetails[activityType]);

  const handleTypeChange = (type: ActivityType) => {
    setActivityType(type);
    setDetails(defaultDetails[type]);
    setIsReduction(false);
  };

  const handleDetailChange = (key: string, value: unknown) => {
    setDetails((prev) => ({ ...prev, [key]: value }));
  };

  const detailFields = useMemo(() => {
    switch (activityType) {
      case 'transport':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Mode</span>
              <select
                className="border rounded px-3 py-2"
                value={details.mode as string}
                onChange={(event) => handleDetailChange('mode', event.target.value)}
              >
                {transportModes.map((mode) => (
                  <option key={mode.value} value={mode.value}>
                    {mode.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Distance (km)</span>
              <input
                type="number"
                min={0}
                className="border rounded px-3 py-2"
                value={details.distance as number}
                onChange={(event) => handleDetailChange('distance', Number(event.target.value))}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Passengers</span>
              <input
                type="number"
                min={1}
                className="border rounded px-3 py-2"
                value={details.passengers as number}
                onChange={(event) => handleDetailChange('passengers', Number(event.target.value))}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Traffic</span>
              <select
                className="border rounded px-3 py-2"
                value={(details.traffic as string) || 'moderate'}
                onChange={(event) => handleDetailChange('traffic', event.target.value)}
              >
                <option value="light">Light</option>
                <option value="moderate">Moderate</option>
                <option value="heavy">Heavy</option>
              </select>
            </label>
          </div>
        );
      case 'energy':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Energy Type</span>
              <select
                className="border rounded px-3 py-2"
                value={details.type as string}
                onChange={(event) => handleDetailChange('type', event.target.value)}
              >
                {energyTypes.map((entry) => (
                  <option key={entry.value} value={entry.value}>
                    {entry.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Usage (kWh)</span>
              <input
                type="number"
                min={0}
                className="border rounded px-3 py-2"
                value={details.usage as number}
                onChange={(event) => handleDetailChange('usage', Number(event.target.value))}
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Renewable Share %</span>
              <input
                type="number"
                min={0}
                max={100}
                className="border rounded px-3 py-2"
                value={details.renewableShare as number}
                onChange={(event) => handleDetailChange('renewableShare', Number(event.target.value))}
              />
            </label>
          </div>
        );
      case 'food':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Meal Type</span>
              <select
                className="border rounded px-3 py-2"
                value={details.type as string}
                onChange={(event) => handleDetailChange('type', event.target.value)}
              >
                {foodTypes.map((entry) => (
                  <option key={entry.value} value={entry.value}>
                    {entry.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Quantity</span>
              <input
                type="number"
                min={0}
                className="border rounded px-3 py-2"
                value={(details.quantity as number) ?? 1}
                onChange={(event) => handleDetailChange('quantity', Number(event.target.value))}
              />
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={Boolean(details.isLocal)}
                onChange={(event) => handleDetailChange('isLocal', event.target.checked)}
              />
              <span className="text-sm">Ingredients sourced locally</span>
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={Boolean(details.isOrganic)}
                onChange={(event) => handleDetailChange('isOrganic', event.target.checked)}
              />
              <span className="text-sm">Organic ingredients</span>
            </label>
          </div>
        );
      case 'waste':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Waste Handling</span>
              <select
                className="border rounded px-3 py-2"
                value={details.type as string}
                onChange={(event) => handleDetailChange('type', event.target.value)}
              >
                {wasteTypes.map((entry) => (
                  <option key={entry.value} value={entry.value}>
                    {entry.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-sm font-medium">Weight (kg)</span>
              <input
                type="number"
                min={0}
                className="border rounded px-3 py-2"
                value={details.weight as number}
                onChange={(event) => handleDetailChange('weight', Number(event.target.value))}
              />
            </label>
          </div>
        );
      default:
        return null;
    }
  }, [activityType, details]);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    await onSubmit({ activityType, details, isReduction });
  };

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="flex flex-wrap gap-3">
        {(['transport', 'energy', 'food', 'waste'] as ActivityType[]).map((type) => (
          <button
            key={type}
            type="button"
            className={`px-4 py-2 rounded border ${activityType === type ? 'bg-green-600 text-white border-green-600' : 'border-slate-300 text-slate-700'}`}
            onClick={() => handleTypeChange(type)}
            disabled={loading}
          >
            {type.charAt(0).toUpperCase() + type.slice(1)}
          </button>
        ))}
      </div>

      {detailFields}

      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={isReduction}
          onChange={(event) => setIsReduction(event.target.checked)}
        />
        <span className="text-sm">Treat as reduction against my baseline</span>
      </label>

      <div className="flex gap-3">
        <button
          type="submit"
          className="px-4 py-2 rounded bg-green-600 text-white hover:bg-green-700 disabled:opacity-60"
          disabled={loading}
        >
          {loading ? 'Logging...' : 'Log Activity'}
        </button>
      </div>
    </form>
  );
};

export default ActivityForm;
