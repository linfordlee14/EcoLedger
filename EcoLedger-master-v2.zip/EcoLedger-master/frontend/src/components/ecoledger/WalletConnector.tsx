import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';

type WalletConnectorProps = {
  onConnected: (params: { address: string; signer: ethers.Signer }) => void;
};

const WalletConnector: React.FC<WalletConnectorProps> = ({ onConnected }) => {
  const [address, setAddress] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const connect = async () => {
    setError(null);
    try {
      if (!window.ethereum) {
        setError('MetaMask not detected. Install a wallet to enable blockchain logging.');
        return;
      }
      const provider = new ethers.BrowserProvider(window.ethereum as any);
      await provider.send('eth_requestAccounts', []);
      const signer = await provider.getSigner();
      const signerAddress = await signer.getAddress();

      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x13881' }],
        });
      } catch (switchError: any) {
        if (switchError?.code === 4902) {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [
              {
                chainId: '0x13881',
                chainName: 'Polygon Mumbai',
                nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
                rpcUrls: ['https://polygon-mumbai-bor.publicnode.com'],
                blockExplorerUrls: ['https://mumbai.polygonscan.com/'],
              },
            ],
          });
        } else {
          throw switchError;
        }
      }

      setAddress(signerAddress);
      onConnected({ address: signerAddress, signer });
    } catch (walletError: any) {
      console.error(walletError);
      setError(walletError?.message || 'Wallet connection failed');
    }
  };

  useEffect(() => {
    if (window.ethereum) {
      const handler = (accounts: string[]) => {
        if (!accounts.length) {
          setAddress(null);
        }
      };
      window.ethereum.on('accountsChanged', handler);
      return () => {
        window.ethereum.removeListener('accountsChanged', handler);
      };
    }
    return undefined;
  }, []);

  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-slate-800">Wallet</p>
          <p className="text-xs text-slate-500">
            {address ? `Connected: ${address.slice(0, 6)}...${address.slice(-4)}` : 'Connect to log rewards on-chain'}
          </p>
        </div>
        <button
          type="button"
          className="px-4 py-2 rounded bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
          onClick={connect}
        >
          {address ? 'Reconnect' : 'Connect Wallet'}
        </button>
      </div>
      {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
    </div>
  );
};

export default WalletConnector;
