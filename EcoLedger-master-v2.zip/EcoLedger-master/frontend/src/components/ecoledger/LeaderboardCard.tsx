import React from 'react';

type LeaderboardEntry = {
  id: string;
  userId?: string;
  totalPoints: number;
  totalEmissions?: number;
  displayName?: string;
  walletAddress?: string | null;
};

type LeaderboardCardProps = {
  entries: LeaderboardEntry[];
};

const LeaderboardCard: React.FC<LeaderboardCardProps> = ({ entries }) => {
  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm h-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-800">Community Leaderboard</h3>
      </div>
      <ul className="space-y-3">
        {entries.map((entry, index) => (
          <li key={entry.id} className="flex items-start gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-green-100 text-green-700 font-semibold">
              {index + 1}
            </span>
            <div className="flex-1">
              <p className="text-sm font-medium text-slate-900">
                {entry.displayName || entry.walletAddress || 'Anonymous member'}
              </p>
              <p className="text-xs text-slate-500">{entry.totalPoints} GreenPoints</p>
              {entry.totalEmissions !== undefined && (
                <p className="text-xs text-slate-400">{entry.totalEmissions} kg logged</p>
              )}
            </div>
          </li>
        ))}
        {!entries.length && (
          <li className="text-sm text-slate-500">No leaderboard data yet. Log your first activity to join!</li>
        )}
      </ul>
    </div>
  );
};

export default LeaderboardCard;
