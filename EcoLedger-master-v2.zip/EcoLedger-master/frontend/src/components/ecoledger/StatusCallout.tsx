import React from 'react';

type StatusCalloutProps = {
  firestoreConfigured: boolean;
  blockchainConfigured: boolean;
  error?: string;
};

const StatusCallout: React.FC<StatusCalloutProps> = ({ firestoreConfigured, blockchainConfigured, error }) => {
  return (
    <div className="border rounded-lg p-4 bg-slate-50">
      <p className="text-sm font-semibold text-slate-700">Platform status</p>
      <ul className="mt-2 space-y-1 text-sm">
        <li>
          <span className="font-medium">Firestore:</span>{' '}
          <span className={firestoreConfigured ? 'text-green-600' : 'text-orange-600'}>
            {firestoreConfigured ? 'connected' : 'configuration required'}
          </span>
        </li>
        <li>
          <span className="font-medium">Blockchain:</span>{' '}
          <span className={blockchainConfigured ? 'text-green-600' : 'text-orange-600'}>
            {blockchainConfigured ? 'connected' : 'awaiting contract deployment'}
          </span>
        </li>
      </ul>
      {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
    </div>
  );
};

export default StatusCallout;
