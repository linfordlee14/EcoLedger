import React, { useEffect } from 'react';
import { useRouter } from 'next/router';

const RegisterPage: React.FC = () => {
  const router = useRouter();
  useEffect(() => {
    router.replace('/login');
  }, [router]);
  return null;
};

export default RegisterPage;
