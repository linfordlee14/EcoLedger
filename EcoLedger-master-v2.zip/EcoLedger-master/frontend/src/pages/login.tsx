import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from '../context/AuthContext';

const LoginPage: React.FC = () => {
  const router = useRouter();
  const { user, loading, signInWithGoogle, signInWithEmail, registerWithEmail } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      router.replace('/dashboard');
    }
  }, [loading, user, router]);

  const handleEmailSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setIsSubmitting(true);
    try {
      await signInWithEmail(email, password);
      toast.success('Logged in');
      router.replace('/dashboard');
    } catch (error: any) {
      if (error?.code === 'auth/user-not-found') {
        try {
          await registerWithEmail(email, password);
          toast.success('Account created');
          router.replace('/dashboard');
        } catch (createError: any) {
          toast.error(createError?.message || 'Unable to register');
        }
      } else {
        toast.error(error?.message || 'Unable to sign in');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogle = async () => {
    try {
      await signInWithGoogle();
      router.replace('/dashboard');
    } catch (error: any) {
      toast.error(error?.message || 'Google sign-in failed');
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center px-4">
      <ToastContainer position="bottom-right" />
      <div className="max-w-md w-full bg-white rounded-lg shadow-sm p-8">
        <h1 className="text-2xl font-semibold text-slate-800 mb-2 text-center">EcoLedger</h1>
        <p className="text-sm text-slate-500 mb-6 text-center">
          Sign in to track your carbon footprint and earn GreenPoints.
        </p>
        <button
          type="button"
          onClick={handleGoogle}
          className="w-full bg-red-500 hover:bg-red-600 text-white py-2 rounded mb-6"
        >
          Continue with Google
        </button>
        <div className="border-t border-slate-200 my-4" />
        <form className="space-y-4" onSubmit={handleEmailSubmit}>
          <div>
            <label className="block text-sm font-medium text-slate-700">Email</label>
            <input
              type="email"
              required
              className="mt-1 w-full border border-slate-300 rounded px-3 py-2"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Password</label>
            <input
              type="password"
              required
              className="mt-1 w-full border border-slate-300 rounded px-3 py-2"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <button
            type="submit"
            className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded disabled:opacity-60"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Signing in...' : 'Sign In or Register'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPage;
