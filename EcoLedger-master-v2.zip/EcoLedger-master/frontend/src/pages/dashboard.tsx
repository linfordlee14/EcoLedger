import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/router';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useAuth } from '../context/AuthContext';
import ActivityForm from '../components/ecoledger/ActivityForm';
import EmissionsChart from '../components/ecoledger/EmissionsChart';
import RecentActivityList from '../components/ecoledger/RecentActivityList';
import LeaderboardCard from '../components/ecoledger/LeaderboardCard';
import RecommendationsList from '../components/ecoledger/RecommendationsList';
import StatusCallout from '../components/ecoledger/StatusCallout';
import WalletConnector from '../components/ecoledger/WalletConnector';
import type { Signer } from 'ethers';
import { fetchOnChainStats } from '../lib/blockchain';
import {
  fetchHistory,
  fetchInsights,
  fetchLeaderboard,
  fetchProfile,
  fetchStatus,
  logEmission,
  updateProfile,
} from '../lib/carbonApi';
import type { ActivityDetails, ActivityType } from '../lib/carbonApi';

const DashboardPage: React.FC = () => {
  const router = useRouter();
  const { user, loading: authLoading, logout } = useAuth();
  const [isFetching, setIsFetching] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [emissions, setEmissions] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [status, setStatus] = useState<{ firestoreConfigured: boolean; blockchainConfigured: boolean; error?: string } | null>(null);
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [onChainStats, setOnChainStats] = useState<any>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.replace('/login');
    }
  }, [authLoading, user, router]);

  const loadData = useCallback(async () => {
    if (!user) return;
    try {
      setIsFetching(true);
      const [profileRes, historyRes, leaderboardRes, insightsRes, statusRes] = await Promise.all([
        fetchProfile().catch(() => ({ profile: null })),
        fetchHistory(20).catch(() => ({ emissions: [] })),
        fetchLeaderboard(10).catch(() => ({ leaderboard: [] })),
        fetchInsights().catch(() => ({ recommendations: [] })),
        fetchStatus().catch(() => ({ firestoreConfigured: false, blockchainConfigured: false })),
      ]);

      setProfile(profileRes.profile);
      setWalletAddress(profileRes.profile?.walletAddress || null);
      setEmissions(historyRes.emissions || []);
      setLeaderboard(leaderboardRes.leaderboard || []);
      setRecommendations(insightsRes.recommendations || []);
      setStatus(statusRes);
      setOnChainStats(null);
    } catch (error) {
      console.error(error);
      toast.error('Failed to load dashboard data.');
    } finally {
      setIsFetching(false);
    }
  }, [user]);

  useEffect(() => {
    if (!authLoading && user) {
      loadData();
    }
  }, [authLoading, user, loadData]);

  const handleLogActivity = async ({ activityType, details, isReduction }: { activityType: ActivityType; details: ActivityDetails; isReduction: boolean }) => {
    try {
      setIsSubmitting(true);
      const response = await logEmission({
        activityType,
        details,
        isReduction,
        walletAddress: walletAddress || undefined,
      });

      if (response?.estimation?.emission !== undefined) {
        const estimated = Number(response.estimation.emission);
        if (!Number.isNaN(estimated)) {
          toast.info(`Estimated ${estimated.toFixed(2)} kg CO2e`);
        }
      }

      toast.success('Activity logged. GreenPoints awarded!');

      if (response?.record?.emission) {
        setEmissions((prev) => [response.record.emission, ...prev].slice(0, 20));
      }
      if (response?.record?.user) {
        setProfile((prev: any) => ({ ...prev, ...response.record.user }));
      }
      loadData();
    } catch (error: any) {
      console.error(error);
      const message = error?.response?.data?.message || 'Unable to log activity';
      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWalletConnected = async ({ address, signer }: { address: string; signer: Signer }) => {
    setWalletAddress(address);
    try {
      await updateProfile({ walletAddress: address });
      toast.success('Wallet connected');
    } catch (error) {
      console.error(error);
      toast.warn('Wallet connected, but failed to persist address. Please update profile later.');
    }

    try {
      const stats = await fetchOnChainStats(signer);
      setOnChainStats(stats);
    } catch (chainError) {
      console.warn(chainError);
      toast.info('On-chain stats unavailable. Deploy contracts and update addresses.json.');
    }
  };

  const emissionTotals = useMemo(() => {
    const total = emissions.reduce((sum, item) => sum + (item.amountKg || 0), 0);
    return {
      total,
      entries: emissions.length,
    };
  }, [emissions]);

  if (authLoading || (isFetching && !profile)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100">
        <p className="text-slate-600">Loading EcoLedger...</p>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-100">
      <ToastContainer position="bottom-right" />
      <header className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800">Welcome back, {user.displayName || user.email}</h1>
            <p className="text-sm text-slate-500">Track your carbon footprint and mint GreenPoints.</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-sm text-slate-500 text-right">
              <p>
                Total logged: <span className="font-semibold text-slate-700">{emissionTotals.total.toFixed(1)} kg</span>
              </p>
              <p>
                Entries: <span className="font-semibold text-slate-700">{emissionTotals.entries}</span>
              </p>
            </div>
            <button
              onClick={logout}
              className="px-4 py-2 rounded bg-slate-800 text-white hover:bg-slate-900"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <div className="lg:col-span-2">
            <div className="border rounded-lg p-6 bg-white shadow-sm">
              <h2 className="text-xl font-semibold text-slate-800 mb-4">Log an Activity</h2>
              <ActivityForm loading={isSubmitting} onSubmit={handleLogActivity} />
            </div>
          </div>
          <div className="space-y-6">
            <WalletConnector onConnected={handleWalletConnected} />
            {status && (
              <StatusCallout
                firestoreConfigured={status.firestoreConfigured}
                blockchainConfigured={status.blockchainConfigured}
                error={status.error}
              />
            )}
            <div className="border rounded-lg p-4 bg-white shadow-sm">
              <h3 className="text-sm font-semibold text-slate-700">Baseline</h3>
              <p className="text-xs text-slate-500 mt-1">
                Monthly goal: {profile?.baseline?.monthly ?? 1000} kg CO2e
              </p>
              {onChainStats && (
                <div className="mt-3 text-xs text-slate-500 space-y-1">
                  <p>On-chain points: <span className="font-semibold text-slate-700">{onChainStats.totalPoints}</span></p>
                  <p>On-chain streak: <span className="font-semibold text-slate-700">{onChainStats.currentStreak}</span></p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 border rounded-lg p-4 bg-white shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-slate-800">Emission Trend</h2>
            </div>
            <EmissionsChart records={emissions} />
          </div>
          <LeaderboardCard entries={leaderboard} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentActivityList records={emissions} />
          <RecommendationsList items={recommendations} />
        </div>
      </main>
    </div>
  );
};

export default DashboardPage;

