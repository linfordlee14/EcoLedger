import axios from 'axios';

export type ActivityType = 'transport' | 'energy' | 'food' | 'waste';

export type ActivityDetails = Record<string, unknown>;

export const calculateEmission = async (activityType: ActivityType, details: ActivityDetails = {}) => {
  const response = await axios.post('/carbon/calculate', { activityType, details });
  return response.data;
};

export const logEmission = async (payload: {
  activityType: ActivityType;
  details: ActivityDetails;
  isReduction?: boolean;
  amountOverride?: number;
  baseline?: {
    monthly?: number;
    transport?: number;
    energy?: number;
    food?: number;
  };
  walletAddress?: string;
  displayName?: string;
}) => {
  const response = await axios.post('/carbon/log', payload);
  return response.data;
};

export const fetchProfile = async () => {
  const response = await axios.get('/carbon/profile');
  return response.data;
};

export const updateProfile = async (payload: {
  baseline?: {
    monthly?: number;
    transport?: number;
    energy?: number;
    food?: number;
  };
  walletAddress?: string;
  displayName?: string;
}) => {
  const response = await axios.post('/carbon/profile', payload);
  return response.data;
};

export const fetchHistory = async (limit = 25) => {
  const response = await axios.get('/carbon/history', { params: { limit } });
  return response.data;
};

export const fetchInsights = async () => {
  const response = await axios.get('/carbon/insights');
  return response.data;
};

export const fetchLeaderboard = async (limit = 10) => {
  const response = await axios.get('/carbon/leaderboard', { params: { limit } });
  return response.data;
};

export const fetchStatus = async () => {
  const response = await axios.get('/carbon/status');
  return response.data;
};
