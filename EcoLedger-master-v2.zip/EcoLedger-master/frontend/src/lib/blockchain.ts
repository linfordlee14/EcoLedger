import { ethers } from 'ethers';
import ecoLedgerAbi from '../contracts/EcoLedger.json';
import addresses from '../contracts/addresses.json';

type ProviderLike = ethers.BrowserProvider | ethers.Signer | ethers.Provider;

export const getEcoLedgerAddress = () => addresses.ecoLedger;
export const getGreenPointsAddress = () => addresses.greenPointsToken;

export const getEcoLedgerContract = async (provider: ProviderLike) => {
  if (!addresses.ecoLedger || addresses.ecoLedger === '0x0000000000000000000000000000000000000000') {
    throw new Error('EcoLedger contract address not configured. Deploy contracts and update addresses.json.');
  }
  const signerOrProvider = provider instanceof ethers.Signer ? provider : provider;
  return new ethers.Contract(addresses.ecoLedger, ecoLedgerAbi, signerOrProvider);
};

export const fetchOnChainStats = async (signer: ethers.Signer) => {
  const contract = await getEcoLedgerContract(signer);
  const address = await signer.getAddress();
  const stats = await contract.getUserStats(address);
  return {
    totalEmissions: Number(stats[0]),
    totalPoints: Number(stats[1]),
    currentStreak: Number(stats[2]),
    recordCount: Number(stats[3]),
  };
};
