require('@nomicfoundation/hardhat-toolbox');
require('dotenv').config();

const { PRIVATE_KEY, BLOCKCHAIN_RPC_URL, POLYGONSCAN_API_KEY } = process.env;

module.exports = {
  solidity: '0.8.23',
  defaultNetwork: 'hardhat',
  networks: {
    hardhat: {},
    localhost: {
      url: 'http://127.0.0.1:8545'
    },
    polygonMumbai: {
      url: BLOCKCHAIN_RPC_URL || 'https://polygon-mumbai-bor.publicnode.com',
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : [],
    }
  },
  etherscan: {
    apiKey: {
      polygonMumbai: POLYGONSCAN_API_KEY || ''
    }
  },
  paths: {
    sources: './contracts',
    tests: './test',
    cache: './cache',
    artifacts: './artifacts'
  }
};
