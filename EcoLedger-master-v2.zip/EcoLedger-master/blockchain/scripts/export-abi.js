const { existsSync, mkdirSync, readFileSync, writeFileSync } = require('fs');
const path = require('path');

const artifactsDir = path.join(__dirname, '..', 'artifacts', 'contracts');

const copyArtifact = (artifactPath, targetPath, options = { abiOnly: false }) => {
  const fullArtifactPath = path.join(artifactsDir, artifactPath);
  if (!existsSync(fullArtifactPath)) {
    console.warn(`Artifact missing: ${artifactPath}`);
    return;
  }
  const artifactRaw = readFileSync(fullArtifactPath, 'utf8');
  const artifact = JSON.parse(artifactRaw);

  const dir = path.dirname(targetPath);
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }

  const data = options.abiOnly ? artifact.abi : artifact;
  writeFileSync(targetPath, JSON.stringify(data, null, 2));
  console.log(`Exported ${artifactPath} -> ${targetPath}`);
};

const run = () => {
  copyArtifact(
    path.join('EcoLedger.sol', 'EcoLedger.json'),
    path.resolve(__dirname, '../../backend/src/blockchain/abi/EcoLedger.json'),
    { abiOnly: true }
  );
  copyArtifact(
    path.join('EcoLedger.sol', 'EcoLedger.json'),
    path.resolve(__dirname, '../../frontend/src/contracts/EcoLedger.json'),
    { abiOnly: true }
  );
  copyArtifact(
    path.join('GreenPointsToken.sol', 'GreenPointsToken.json'),
    path.resolve(__dirname, '../../frontend/src/contracts/GreenPointsToken.json'),
    { abiOnly: true }
  );
};

run();
