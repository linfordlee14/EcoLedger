const { writeFileSync, mkdirSync, existsSync } = require('fs');
const path = require('path');
const hre = require('hardhat');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const OUTPUT_DIR = path.join(__dirname, '..', 'deployments');

const writeJson = (filePath, data) => {
  const dir = path.dirname(filePath);
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
  writeFileSync(filePath, JSON.stringify(data, null, 2));
};

const tryWrite = (relativePath, data) => {
  try {
    writeJson(path.resolve(__dirname, relativePath), data);
    console.log(`Saved deployment info to ${relativePath}`);
  } catch (error) {
    console.warn(`Could not write ${relativePath}: ${error.message}`);
  }
};

async function main() {
  console.log('Deploying GreenPointsToken...');
  const Token = await hre.ethers.getContractFactory('GreenPointsToken');
  const token = await Token.deploy();
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  console.log(`GreenPointsToken deployed at ${tokenAddress}`);

  console.log('Deploying EcoLedger...');
  const EcoLedger = await hre.ethers.getContractFactory('EcoLedger');
  const ecoLedger = await EcoLedger.deploy(tokenAddress);
  await ecoLedger.waitForDeployment();
  const ecoLedgerAddress = await ecoLedger.getAddress();
  console.log(`EcoLedger deployed at ${ecoLedgerAddress}`);

  console.log('Transferring token ownership to EcoLedger contract...');
  const tx = await token.transferOwnership(ecoLedgerAddress);
  await tx.wait();
  console.log('Ownership transferred.');

  const deployment = {
    network: hre.network.name,
    timestamp: new Date().toISOString(),
    greenPointsToken: tokenAddress,
    ecoLedger: ecoLedgerAddress,
  };

  writeJson(path.join(OUTPUT_DIR, `${hre.network.name}.json`), deployment);
  writeJson(path.join(OUTPUT_DIR, 'latest.json'), deployment);

  tryWrite('../../frontend/src/contracts/addresses.json', deployment);
  tryWrite('../../backend/src/blockchain/addresses.json', deployment);

  console.log('Deployment complete.');
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
