const path = require('path');
const hre = require('hardhat');

const loadDeployment = () => {
  try {
    return require('../deployments/latest.json');
  } catch (error) {
    throw new Error('Deployment file not found. Run a deployment first.');
  }
};

async function main() {
  const { ecoLedger, greenPointsToken } = loadDeployment();
  const [signer] = await hre.ethers.getSigners();

  console.log(`Using signer ${await signer.getAddress()}`);

  const ecoLedgerContract = await hre.ethers.getContractAt('EcoLedger', ecoLedger);
  const tokenContract = await hre.ethers.getContractAt('GreenPointsToken', greenPointsToken);

  const registerTx = await ecoLedgerContract.registerUser(1000);
  await registerTx.wait();
  console.log('Registered user with baseline 1000kg.');

  const logTx = await ecoLedgerContract.logEmission(30, 'transport', false);
  await logTx.wait();
  console.log('Logged emission of 30kg transport.');

  const stats = await ecoLedgerContract.getUserStats(await signer.getAddress());
  console.log('User stats:', stats);

  const balance = await tokenContract.balanceOf(await signer.getAddress());
  console.log('GreenPoints balance:', balance.toString());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
