#!/usr/bin/env bash
yarn start
