#test - template backend,

#### Run App on local machine:

##### Install local dependencies:

- `yarn install`

---

##### Start build:

- `yarn start`
